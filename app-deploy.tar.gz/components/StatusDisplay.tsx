import React, { useState, useEffect } from 'react';
import { JobStatus } from '../src/types';

interface StatusDisplayProps {
  jobId: string;
}

export const StatusDisplay: React.FC<StatusDisplayProps> = ({ jobId }) => {
  const [status, setStatus] = useState<JobStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isPolling, setIsPolling] = useState(true);

  useEffect(() => {
    let intervalId: NodeJS.Timeout | null = null;

    const pollStatus = async () => {
      try {
        const response = await fetch(`/api/status/${jobId}`);
        const result = await response.json();

        if (result.success) {
          setStatus(result.data);
          setError(null);

          // Stop polling if job is completed or failed
          if (result.data.status === 'completed' || result.data.status === 'failed') {
            setIsPolling(false);
          }
        } else {
          setError(result.error?.message || 'Failed to fetch status');
          setIsPolling(false);
        }
      } catch (error) {
        console.error('Status polling error:', error);
        setError('Failed to connect to server');
        setIsPolling(false);
      }
    };

    // Initial poll
    pollStatus();

    // Set up polling if needed
    if (isPolling) {
      intervalId = setInterval(pollStatus, 2000); // Poll every 2 seconds
    }

    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [jobId, isPolling]);

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="rounded-md bg-red-50 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Status Error</h3>
              <p className="mt-2 text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!status) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-2 bg-gray-200 rounded w-full mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600';
      case 'failed': return 'text-red-600';
      case 'processing': return 'text-blue-600';
      default: return 'text-yellow-600';
    }
  };

  const getProgressBarColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-600';
      case 'failed': return 'bg-red-600';
      case 'processing': return 'bg-blue-600';
      default: return 'bg-yellow-600';
    }
  };

  const getStepIcon = (currentStep: string, step: string, status: string) => {
    const isActive = currentStep === step;
    const isCompleted = getStepOrder(currentStep) > getStepOrder(step) || 
                      (status === 'completed' && currentStep === step);
    const isFailed = status === 'failed' && currentStep === step;

    if (isFailed) {
      return (
        <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
          <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </div>
      );
    }

    if (isCompleted) {
      return (
        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
          <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
      );
    }

    if (isActive) {
      return (
        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
          <div className="w-3 h-3 bg-blue-600 rounded-full animate-pulse"></div>
        </div>
      );
    }

    return (
      <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
        <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
      </div>
    );
  };

  const getStepOrder = (step: string): number => {
    const stepOrder = {
      'upload': 1,
      'segmentation': 2,
      'extraction': 3,
      'analysis': 4,
      'compilation': 5,
      'synthesis': 6,
    };
    return stepOrder[step as keyof typeof stepOrder] || 0;
  };

  const steps = [
    { key: 'upload', label: 'Upload', description: 'Video uploaded to S3' },
    { key: 'segmentation', label: 'Segmentation', description: 'Analyzing video segments' },
    { key: 'extraction', label: 'Extraction', description: 'Extracting video scenes' },
    { key: 'analysis', label: 'Analysis', description: 'AI scene analysis' },
    { key: 'compilation', label: 'Compilation', description: 'Compiling descriptions' },
    { key: 'synthesis', label: 'Synthesis', description: 'Generating audio' },
  ];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xl font-semibold text-gray-900">Processing Status</h2>
          <span className={`text-sm font-medium ${getStatusColor(status.status)}`}>
            {status.status.charAt(0).toUpperCase() + status.status.slice(1)}
          </span>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
          <div
            className={`h-2 rounded-full transition-all duration-300 ${getProgressBarColor(status.status)}`}
            style={{ width: `${status.progress}%` }}
          ></div>
        </div>

        <div className="flex items-center justify-between text-sm text-gray-600">
          <span>Job ID: {status.jobId}</span>
          <span>{status.progress}% Complete</span>
        </div>
      </div>

      {/* Current Status Message */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <p className="text-sm text-gray-700">{status.message}</p>
        {status.error && (
          <div className="mt-2 p-2 bg-red-50 rounded border border-red-200">
            <p className="text-sm text-red-700 font-medium">Error: {status.error.message}</p>
            {status.error.details && (
              <p className="text-xs text-red-600 mt-1">{status.error.details}</p>
            )}
          </div>
        )}
      </div>

      {/* Processing Steps */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium text-gray-900">Processing Steps</h3>
        <div className="space-y-3">
          {steps.map((step, index) => (
            <div key={step.key} className="flex items-center space-x-3">
              {getStepIcon(status.step, step.key, status.status)}
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">{step.label}</p>
                <p className="text-xs text-gray-500">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Timestamps */}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
          <div>
            <span className="font-medium">Started:</span>
            <br />
            {new Date(status.createdAt).toLocaleString()}
          </div>
          <div>
            <span className="font-medium">Last Updated:</span>
            <br />
            {new Date(status.updatedAt).toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  );
};