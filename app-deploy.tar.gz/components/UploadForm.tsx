import React, { useState, useCallback, useRef } from 'react';

interface UploadFormProps {
  onUploadSuccess: (jobId: string) => void;
}

export const UploadForm: React.FC<UploadFormProps> = ({ onUploadSuccess }) => {
  const [uploading, setUploading] = useState(false);
  const [uploadMode, setUploadMode] = useState<'file' | 's3uri'>('file');
  const [s3Uri, setS3Uri] = useState('');
  const [metadata, setMetadata] = useState({
    title: '',
    description: '',
    language: 'en',
  });
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = useCallback(async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      
      if (uploadMode === 'file') {
        const file = fileInputRef.current?.files?.[0];
        if (!file) {
          throw new Error('Please select a video file');
        }
        formData.append('video', file);
      } else {
        if (!s3Uri.trim()) {
          throw new Error('Please enter a valid S3 URI');
        }
        formData.append('s3Uri', s3Uri.trim());
      }

      // Add metadata
      formData.append('title', metadata.title);
      formData.append('description', metadata.description);
      formData.append('language', metadata.language);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error?.message || 'Upload failed');
      }

      onUploadSuccess(result.data.jobId);

    } catch (error) {
      console.error('Upload error:', error);
      setError(error instanceof Error ? error.message : 'Upload failed');
    } finally {
      setUploading(false);
    }
  }, [uploadMode, s3Uri, metadata, onUploadSuccess]);

  return (
    <div className="bg-white rounded-lg shadow-lg p-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Upload Video</h2>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleFileUpload} className="space-y-6">
        {/* Upload Mode Selection */}
        <div>
          <label className="text-base font-medium text-gray-900">Upload Method</label>
          <p className="text-sm leading-5 text-gray-500">Choose how to provide your video</p>
          <fieldset className="mt-4">
            <legend className="sr-only">Upload method</legend>
            <div className="space-y-4">
              <div className="flex items-center">
                <input
                  id="file-upload"
                  name="upload-method"
                  type="radio"
                  className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300"
                  checked={uploadMode === 'file'}
                  onChange={() => setUploadMode('file')}
                />
                <label htmlFor="file-upload" className="ml-3 block text-sm font-medium text-gray-700">
                  Upload file from computer
                </label>
              </div>
              <div className="flex items-center">
                <input
                  id="s3-uri"
                  name="upload-method"
                  type="radio"
                  className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300"
                  checked={uploadMode === 's3uri'}
                  onChange={() => setUploadMode('s3uri')}
                />
                <label htmlFor="s3-uri" className="ml-3 block text-sm font-medium text-gray-700">
                  Use existing S3 URI
                </label>
              </div>
            </div>
          </fieldset>
        </div>

        {/* File Upload */}
        {uploadMode === 'file' && (
          <div>
            <label htmlFor="video-file" className="block text-sm font-medium text-gray-700">
              Video File
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                <svg
                  className="mx-auto h-12 w-12 text-gray-400"
                  stroke="currentColor"
                  fill="none"
                  viewBox="0 0 48 48"
                >
                  <path
                    d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                    strokeWidth={2}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <div className="flex text-sm text-gray-600">
                  <label
                    htmlFor="video-file"
                    className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500"
                  >
                    <span>Upload a video file</span>
                    <input
                      id="video-file"
                      ref={fileInputRef}
                      name="video-file"
                      type="file"
                      accept="video/*"
                      className="sr-only"
                    />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">MP4, AVI, MOV up to 500MB</p>
              </div>
            </div>
          </div>
        )}

        {/* S3 URI Input */}
        {uploadMode === 's3uri' && (
          <div>
            <label htmlFor="s3-uri-input" className="block text-sm font-medium text-gray-700">
              S3 URI
            </label>
            <div className="mt-1">
              <input
                type="text"
                id="s3-uri-input"
                className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                placeholder="s3://bucket-name/path/to/video.mp4"
                value={s3Uri}
                onChange={(e) => setS3Uri(e.target.value)}
              />
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Enter the S3 URI of a video file that's already uploaded to AWS S3
            </p>
          </div>
        )}

        {/* Metadata */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700">
              Title (Optional)
            </label>
            <div className="mt-1">
              <input
                type="text"
                id="title"
                className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                placeholder="My Video Title"
                value={metadata.title}
                onChange={(e) => setMetadata({ ...metadata, title: e.target.value })}
              />
            </div>
          </div>

          <div>
            <label htmlFor="language" className="block text-sm font-medium text-gray-700">
              Language
            </label>
            <div className="mt-1">
              <select
                id="language"
                className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                value={metadata.language}
                onChange={(e) => setMetadata({ ...metadata, language: e.target.value })}
              >
                <option value="en">English</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
                <option value="de">German</option>
                <option value="it">Italian</option>
                <option value="pt">Portuguese</option>
              </select>
            </div>
          </div>
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
            Description (Optional)
          </label>
          <div className="mt-1">
            <textarea
              id="description"
              rows={3}
              className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
              placeholder="Brief description of the video content..."
              value={metadata.description}
              onChange={(e) => setMetadata({ ...metadata, description: e.target.value })}
            />
          </div>
        </div>

        {/* Submit Button */}
        <div>
          <button
            type="submit"
            disabled={uploading}
            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {uploading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </>
            ) : (
              'Start Processing'
            )}
          </button>
        </div>
      </form>
    </div>
  );
};