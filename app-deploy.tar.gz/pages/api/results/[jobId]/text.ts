import { NextApiRequest, NextApiResponse } from 'next';
import { JobManager } from '../../../../src/orchestrator/jobManager';
import { AWSConfig } from '../../../../src/types';
import { logger } from '../../../../src/utils/logger';

// Initialize JobManager
const awsConfig: AWSConfig = {
  region: process.env.AWS_DEFAULT_REGION || 'us-east-1',
  inputBucket: process.env.INPUT_S3_BUCKET!,
  outputBucket: process.env.OUTPUT_S3_BUCKET!,
  credentials: process.env.AWS_ACCESS_KEY_ID ? {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  } : undefined,
};

const jobManager = new JobManager(awsConfig);

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({
      success: false,
      error: {
        code: 'METHOD_NOT_ALLOWED',
        message: 'Only GET method allowed',
      },
      timestamp: new Date(),
    });
  }

  try {
    const { jobId } = req.query;
    const { format = 'clean' } = req.query; // 'clean' or 'timestamped'

    if (!jobId || typeof jobId !== 'string') {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_JOB_ID',
          message: 'Valid job ID is required',
        },
        timestamp: new Date(),
      });
    }

    logger.debug('Text result request received', { jobId, format });

    const job = jobManager.getJob(jobId);

    if (!job) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'JOB_NOT_FOUND',
          message: `Job ${jobId} not found`,
        },
        timestamp: new Date(),
      });
    }

    if (job.status.status !== 'completed') {
      return res.status(409).json({
        success: false,
        error: {
          code: 'JOB_NOT_COMPLETED',
          message: `Job ${jobId} is not completed yet. Current status: ${job.status.status}`,
        },
        timestamp: new Date(),
      });
    }

    const compiledDescription = (job as any).compiledDescription;

    if (!compiledDescription) {
      return res.status(500).json({
        success: false,
        error: {
          code: 'NO_TEXT_AVAILABLE',
          message: 'No compiled text description available for this job',
        },
        timestamp: new Date(),
      });
    }

    // Return appropriate format
    const textContent = format === 'timestamped' 
      ? compiledDescription.timestampedText 
      : compiledDescription.cleanText;

    // Set appropriate headers for download
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="description-${jobId}.txt"`);

    logger.info('Text result served', { jobId, format, length: textContent.length });

    return res.status(200).send(textContent);

  } catch (error) {
    logger.error('Text result handler error', { error, jobId: req.query.jobId });

    return res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: 'An unexpected error occurred',
        details: error instanceof Error ? error.message : String(error),
      },
      timestamp: new Date(),
    });
  }
}