import { NextApiRequest, NextApiResponse } from 'next';
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { JobManager } from '../../../../src/orchestrator/jobManager';
import { AWSConfig } from '../../../../src/types';
import { logger } from '../../../../src/utils/logger';

// Initialize JobManager and S3 client
const awsConfig: AWSConfig = {
  region: process.env.AWS_DEFAULT_REGION || 'us-east-1',
  inputBucket: process.env.INPUT_S3_BUCKET!,
  outputBucket: process.env.OUTPUT_S3_BUCKET!,
  credentials: process.env.AWS_ACCESS_KEY_ID ? {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  } : undefined,
};

const jobManager = new JobManager(awsConfig);
const s3Client = new S3Client({
  region: awsConfig.region,
  credentials: awsConfig.credentials,
});

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({
      success: false,
      error: {
        code: 'METHOD_NOT_ALLOWED',
        message: 'Only GET method allowed',
      },
      timestamp: new Date(),
    });
  }

  try {
    const { jobId } = req.query;

    if (!jobId || typeof jobId !== 'string') {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_JOB_ID',
          message: 'Valid job ID is required',
        },
        timestamp: new Date(),
      });
    }

    logger.debug('Audio result request received', { jobId });

    const job = jobManager.getJob(jobId);

    if (!job) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'JOB_NOT_FOUND',
          message: `Job ${jobId} not found`,
        },
        timestamp: new Date(),
      });
    }

    if (job.status.status !== 'completed') {
      return res.status(409).json({
        success: false,
        error: {
          code: 'JOB_NOT_COMPLETED',
          message: `Job ${jobId} is not completed yet. Current status: ${job.status.status}`,
        },
        timestamp: new Date(),
      });
    }

    if (!job.audioUri) {
      return res.status(500).json({
        success: false,
        error: {
          code: 'NO_AUDIO_AVAILABLE',
          message: 'No audio file available for this job',
        },
        timestamp: new Date(),
      });
    }

    // Parse S3 URI
    const s3UriMatch = job.audioUri.match(/^s3:\/\/([^\/]+)\/(.+)$/);
    if (!s3UriMatch) {
      return res.status(500).json({
        success: false,
        error: {
          code: 'INVALID_AUDIO_URI',
          message: 'Invalid audio S3 URI format',
        },
        timestamp: new Date(),
      });
    }

    const [, bucket, key] = s3UriMatch;

    // Get audio file from S3
    const command = new GetObjectCommand({
      Bucket: bucket,
      Key: key,
    });

    const s3Response = await s3Client.send(command);

    if (!s3Response.Body) {
      return res.status(500).json({
        success: false,
        error: {
          code: 'EMPTY_AUDIO_FILE',
          message: 'Audio file is empty or corrupted',
        },
        timestamp: new Date(),
      });
    }

    // Set appropriate headers for audio download
    res.setHeader('Content-Type', s3Response.ContentType || 'audio/mpeg');
    res.setHeader('Content-Length', s3Response.ContentLength || 0);
    res.setHeader('Content-Disposition', `attachment; filename="audio-${jobId}.mp3"`);
    res.setHeader('Cache-Control', 'public, max-age=3600'); // Cache for 1 hour

    // Stream the audio data
    const webStream = s3Response.Body.transformToWebStream();
    const reader = webStream.getReader();

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(Buffer.from(value));
      }
    } finally {
      reader.releaseLock();
    }

    logger.info('Audio result served', { 
      jobId, 
      audioUri: job.audioUri,
      contentLength: s3Response.ContentLength 
    });

    res.end();

  } catch (error) {
    logger.error('Audio result handler error', { error, jobId: req.query.jobId });

    // If response hasn't started, send JSON error
    if (!res.headersSent) {
      return res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_SERVER_ERROR',
          message: 'An unexpected error occurred while retrieving audio',
          details: error instanceof Error ? error.message : String(error),
        },
        timestamp: new Date(),
      });
    }

    // If response has started, just end it
    res.end();
  }
}