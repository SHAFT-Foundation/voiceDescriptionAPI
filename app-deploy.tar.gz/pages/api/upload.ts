import { NextApiRequest, NextApiResponse } from 'next';
import { JobManager } from '../../src/orchestrator/jobManager';
import { AWSConfig, UploadRequest } from '../../src/types';
import { logger } from '../../src/utils/logger';
import multer from 'multer';
import { promisify } from 'util';

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB limit
  },
  fileFilter: (req, file, cb) => {
    // Accept video files only
    if (file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only video files are allowed'));
    }
  },
});

const uploadMiddleware = promisify(upload.single('video'));

// Initialize JobManager
const awsConfig: AWSConfig = {
  region: process.env.AWS_DEFAULT_REGION || 'us-east-1',
  inputBucket: process.env.INPUT_S3_BUCKET!,
  outputBucket: process.env.OUTPUT_S3_BUCKET!,
  credentials: process.env.AWS_ACCESS_KEY_ID ? {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  } : undefined,
};

const jobManager = new JobManager(awsConfig);

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      error: {
        code: 'METHOD_NOT_ALLOWED',
        message: 'Only POST method allowed',
      },
      timestamp: new Date(),
    });
  }

  try {
    logger.info('Upload request received', { 
      headers: req.headers,
      query: req.query 
    });

    // Handle multipart file upload
    await uploadMiddleware(req as any, res as any);

    const file = (req as any).file;
    const { s3Uri, title, description, language } = req.body;

    // Validate request
    if (!file && !s3Uri) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'MISSING_INPUT',
          message: 'Either file upload or S3 URI must be provided',
        },
        timestamp: new Date(),
      });
    }

    // Prepare upload request
    const uploadRequest: UploadRequest = {
      file: file ? file.buffer : undefined,
      s3Uri: s3Uri || undefined,
      metadata: {
        title: title || 'Untitled Video',
        description: description || '',
        language: language || 'en',
      },
    };

    // Create job
    const result = await jobManager.createJob(uploadRequest);

    if (!result.success) {
      logger.error('Job creation failed', { error: result.error });
      return res.status(400).json(result);
    }

    const { jobId } = result.data!;

    // Start processing asynchronously (don't await)
    jobManager.processJob(jobId).catch(error => {
      logger.error('Async job processing failed', { error, jobId });
    });

    logger.info('Upload successful, job created', { jobId });

    return res.status(200).json({
      success: true,
      data: {
        jobId,
        message: 'Video uploaded successfully, processing started',
        statusUrl: `/api/status/${jobId}`,
      },
      timestamp: new Date(),
    });

  } catch (error) {
    logger.error('Upload handler error', { error });

    if (error instanceof Error && error.message.includes('Only video files')) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_FILE_TYPE',
          message: 'Only video files are allowed',
        },
        timestamp: new Date(),
      });
    }

    if (error instanceof Error && error.message.includes('File too large')) {
      return res.status(413).json({
        success: false,
        error: {
          code: 'FILE_TOO_LARGE',
          message: 'File size exceeds 500MB limit',
        },
        timestamp: new Date(),
      });
    }

    return res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: 'An unexpected error occurred',
        details: error instanceof Error ? error.message : String(error),
      },
      timestamp: new Date(),
    });
  }
}

// Disable default body parser for multipart
export const config = {
  api: {
    bodyParser: false,
  },
};