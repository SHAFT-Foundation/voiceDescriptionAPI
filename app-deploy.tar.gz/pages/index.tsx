import React, { useState, useCallback } from 'react';
import Head from 'next/head';
import { UploadForm } from '../components/UploadForm';
import { StatusDisplay } from '../components/StatusDisplay';
import { ResultsDisplay } from '../components/ResultsDisplay';

export default function Home() {
  const [currentJobId, setCurrentJobId] = useState<string | null>(null);
  const [uploadComplete, setUploadComplete] = useState<boolean>(false);

  const handleUploadSuccess = useCallback((jobId: string) => {
    setCurrentJobId(jobId);
    setUploadComplete(true);
  }, []);

  const handleReset = useCallback(() => {
    setCurrentJobId(null);
    setUploadComplete(false);
  }, []);

  return (
    <>
      <Head>
        <title>Voice Description API</title>
        <meta name="description" content="Generate audio descriptions for videos to improve accessibility" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <header className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Voice Description API
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Generate descriptive audio narration tracks for videos to improve accessibility 
              for visually impaired audiences using AI-powered scene analysis.
            </p>
          </header>

          {/* Main Content */}
          <div className="max-w-4xl mx-auto">
            {!uploadComplete ? (
              <UploadForm onUploadSuccess={handleUploadSuccess} />
            ) : (
              <div className="space-y-8">
                <StatusDisplay jobId={currentJobId!} />
                <ResultsDisplay jobId={currentJobId!} />
                
                {/* Reset Button */}
                <div className="text-center">
                  <button
                    onClick={handleReset}
                    className="inline-flex items-center px-6 py-3 border border-gray-300 shadow-sm text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    <svg
                      className="w-5 h-5 mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 4v16m8-8H4"
                      />
                    </svg>
                    Process Another Video
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Features Section */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-white rounded-lg shadow-sm">
              <div className="w-12 h-12 mx-auto mb-4 bg-blue-100 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                AI-Powered Analysis
              </h3>
              <p className="text-gray-600">
                Uses Amazon Bedrock Nova Pro to analyze video scenes and generate natural descriptions.
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-lg shadow-sm">
              <div className="w-12 h-12 mx-auto mb-4 bg-green-100 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                High-Quality Audio
              </h3>
              <p className="text-gray-600">
                Generates natural-sounding audio using Amazon Polly text-to-speech technology.
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-lg shadow-sm">
              <div className="w-12 h-12 mx-auto mb-4 bg-purple-100 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Secure & Scalable
              </h3>
              <p className="text-gray-600">
                Built on AWS infrastructure with secure processing and automatic cleanup.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}