#!/bin/bash

# Update system
apt-get update -y

# Install Docker
apt-get install -y docker.io docker-compose
systemctl start docker
systemctl enable docker
usermod -aG docker ubuntu

# Install Node.js and npm
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt-get install -y nodejs

# Install AWS CLI
apt-get install -y awscli

# Install CloudWatch agent
wget https://s3.amazonaws.com/amazoncloudwatch-agent/ubuntu/amd64/latest/amazon-cloudwatch-agent.deb
dpkg -i amazon-cloudwatch-agent.deb

# Install FFmpeg
apt-get install -y ffmpeg

# Create application directory
mkdir -p /opt/voice-description-api
cd /opt/voice-description-api

# Clone or copy application files (this would be replaced with actual deployment)
# For demo, we'll create a simple deployment script placeholder
cat > deploy.sh << 'EOF'
#!/bin/bash

# Set environment variables
export NODE_ENV=production
export AWS_DEFAULT_REGION=${AWS_REGION}
export INPUT_S3_BUCKET=${INPUT_S3_BUCKET}
export OUTPUT_S3_BUCKET=${OUTPUT_S3_BUCKET}
export PORT=3000

# Set additional configuration
export NOVA_MODEL_ID="amazon.nova-pro-v1:0"
export POLLY_VOICE_ID="Joanna"
export MAX_VIDEO_SIZE_MB=500
export PROCESSING_TIMEOUT_MINUTES=30
export LOG_LEVEL=info

# Create logs directory
mkdir -p /opt/voice-description-api/logs

# Install dependencies and start application
# This would typically pull from a repository or artifact store
echo "Application deployment script ready"
echo "Manual deployment required: copy application files and run npm install && npm run build && npm start"
EOF

chmod +x deploy.sh

# Create systemd service file
cat > /etc/systemd/system/voice-description-api.service << 'EOF'
[Unit]
Description=Voice Description API
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/opt/voice-description-api
Environment=NODE_ENV=production
Environment=AWS_DEFAULT_REGION=${AWS_REGION}
Environment=INPUT_S3_BUCKET=${INPUT_S3_BUCKET}
Environment=OUTPUT_S3_BUCKET=${OUTPUT_S3_BUCKET}
Environment=PORT=3000
Environment=NOVA_MODEL_ID=amazon.nova-pro-v1:0
Environment=POLLY_VOICE_ID=Joanna
Environment=MAX_VIDEO_SIZE_MB=500
Environment=PROCESSING_TIMEOUT_MINUTES=30
Environment=LOG_LEVEL=info
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Configure CloudWatch agent
cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json << 'EOF'
{
  "logs": {
    "logs_collected": {
      "files": {
        "collect_list": [
          {
            "file_path": "/opt/voice-description-api/logs/error.log",
            "log_group_name": "/aws/ec2/voice-description-api-${ENVIRONMENT}",
            "log_stream_name": "error-log"
          },
          {
            "file_path": "/opt/voice-description-api/logs/combined.log",
            "log_group_name": "/aws/ec2/voice-description-api-${ENVIRONMENT}",
            "log_stream_name": "application-log"
          }
        ]
      }
    }
  },
  "metrics": {
    "namespace": "VoiceDescriptionAPI",
    "metrics_collected": {
      "cpu": {
        "measurement": [
          "cpu_usage_idle",
          "cpu_usage_iowait",
          "cpu_usage_user",
          "cpu_usage_system"
        ],
        "metrics_collection_interval": 60
      },
      "disk": {
        "measurement": [
          "used_percent"
        ],
        "metrics_collection_interval": 60,
        "resources": [
          "*"
        ]
      },
      "mem": {
        "measurement": [
          "mem_used_percent"
        ],
        "metrics_collection_interval": 60
      }
    }
  }
}
EOF

# Start CloudWatch agent
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl \
  -a fetch-config \
  -m ec2 \
  -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json \
  -s

# Set ownership
chown -R ubuntu:ubuntu /opt/voice-description-api

# Create startup script
cat > /home/ubuntu/start-app.sh << 'EOF'
#!/bin/bash
cd /opt/voice-description-api
echo "Starting Voice Description API..."
echo "Environment: ${ENVIRONMENT}"
echo "Input Bucket: ${INPUT_S3_BUCKET}"
echo "Output Bucket: ${OUTPUT_S3_BUCKET}"
echo "AWS Region: ${AWS_REGION}"
echo ""
echo "To deploy the application:"
echo "1. Copy application files to /opt/voice-description-api"
echo "2. Run: npm install"
echo "3. Run: npm run build"
echo "4. Run: sudo systemctl enable voice-description-api"
echo "5. Run: sudo systemctl start voice-description-api"
echo ""
echo "Check status with: sudo systemctl status voice-description-api"
echo "View logs with: journalctl -u voice-description-api -f"
EOF

chmod +x /home/ubuntu/start-app.sh
chown ubuntu:ubuntu /home/ubuntu/start-app.sh

# Install nginx for reverse proxy
apt-get install -y nginx

# Configure nginx
cat > /etc/nginx/sites-available/voice-description-api << 'EOF'
server {
    listen 80;
    server_name _;

    client_max_body_size 500M;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 300s;
        proxy_send_timeout 300s;
    }
}
EOF

# Enable nginx site
ln -s /etc/nginx/sites-available/voice-description-api /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default
systemctl restart nginx
systemctl enable nginx

echo "Server setup complete. Application ready for deployment."